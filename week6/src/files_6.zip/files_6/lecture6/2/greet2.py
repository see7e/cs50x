# Printing command-line arguments

from sys import argv

for arg in argv:
    print(arg)
