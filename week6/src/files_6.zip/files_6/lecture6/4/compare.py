# Compares two strings

# Get two strings
s = input("s: ")
t = input("t: ")

# Compare strings
if s == t:
    print("Same")
else:
    print("Different")
